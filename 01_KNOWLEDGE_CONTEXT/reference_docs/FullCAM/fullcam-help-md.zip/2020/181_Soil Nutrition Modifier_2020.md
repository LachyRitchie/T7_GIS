+----------------------------------------------+-----------------------+-----------------------+
| [![coat of                                   |                       | [](index.htm)         |
| arms](imgs/DISER-inline_Mono.png){border="0" |                       |                       |
| width="320"}](http://www.industry.gov.au)    |                       | # FullCAM Help        |
+----------------------------------------------+-----------------------+-----------------------+
|                                              |                       |                       |
+----------------------------------------------+-----------------------+-----------------------+

**Soil Nutrition Modifier**

\[[Site : Productivity](64_Site_Productivity.htm) window : *Soil
Nutrition Modifier* button\]

This [Time Series Window](135_time-series%20window.htm) is where enter
the soil nutrition modifier rating for the plot.

**Details**

The soil nutrition modifier is dimensionless, and typically between 0.75
and 1.25. Higher values result in more NPP being produced by the trees.

------------------------------------------------------------------------

© 2025 [Department of Industry, Science, Energy and
Resources](http://www.industry.gov.au "Department of Industry, Science, Energy and Resources"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
