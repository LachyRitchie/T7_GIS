+----------------------------------------------+-----------------------+-----------------------+
| [![coat of                                   |                       | [](index.htm)         |
| arms](imgs/DISER-inline_Mono.png){border="0" |                       |                       |
| width="320"}](http://www.industry.gov.au)    |                       | # FullCAM Help        |
+----------------------------------------------+-----------------------+-----------------------+
|                                              |                       |                       |
+----------------------------------------------+-----------------------+-----------------------+

**Select A Standard Event**

\[[Event Window](137_Event%20Window.htm) : *Insert Standard Values*
button\]

This window is for choosing between the available standard events, when
inserting standard values into an event.

**Use**

Select a standard event then press the *OK* button, or double-click on
an event. The event thus chosen will be the one whose values replace the
event currently being edited.

The standard events all belong to a species. You can choose any one of
the events of the appropriate type, regardless of species.

Events in red are not ready.

See [Standard Events of a
Species](142_Standard%20Events%20of%20a%20Species.htm)

------------------------------------------------------------------------

© 2025 [Department of Industry, Science, Energy and
Resources](http://www.industry.gov.au "Department of Industry, Science, Energy and Resources"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
