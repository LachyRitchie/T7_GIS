+----------------------------------------------+-----------------------+-----------------------+
| [![coat of                                   |                       | [](index.htm)         |
| arms](imgs/DISER-inline_Mono.png){border="0" |                       |                       |
| width="320"}](http://www.industry.gov.au)    |                       | # FullCAM Help        |
+----------------------------------------------+-----------------------+-----------------------+
|                                              |                       |                       |
+----------------------------------------------+-----------------------+-----------------------+

**Frost Nights**

\[[Site : Temperature](13_Site_Temperature.htm) window : *Frost Nights*
button\]

This [Time Series Window](135_time-series%20window.htm) is where you
enter the number of nights in which any frost occurs. For example, if
there were frosts on the nights of March 12, 14 and 16 (only) in March
1963 then the time series value for March 1963 would be "3".

------------------------------------------------------------------------

© 2025 [Department of Industry, Science, Energy and
Resources](http://www.industry.gov.au "Department of Industry, Science, Energy and Resources"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
