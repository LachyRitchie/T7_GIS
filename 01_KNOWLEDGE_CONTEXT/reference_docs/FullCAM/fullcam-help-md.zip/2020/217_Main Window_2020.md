+----------------------------------------------+-----------------------+-----------------------+
| [![coat of                                   |                       | [](index.htm)         |
| arms](imgs/DISER-inline_Mono.png){border="0" |                       |                       |
| width="320"}](http://www.industry.gov.au)    |                       | # FullCAM Help        |
+----------------------------------------------+-----------------------+-----------------------+
|                                              |                       |                       |
+----------------------------------------------+-----------------------+-----------------------+

**Main Window**

This window is the thin window across the top of your screen with a menu
and toolbar, entitled "FullCAM X.X \[PR 2020\]", where X.X is the
version number of the FullCAM program.

The main window is open whenever FullCAM is open. It is the window
called "FullCAM" in the Windows Taskbar. Individual FullCAM documents or
windows do not get their own buttons on the Windows Taskbar.

If you close the main window then you exit FullCAM.

The main window contains the only fixed menus.

You cannot resize the main window, although you can move it.

------------------------------------------------------------------------

© 2025 [Department of Industry, Science, Energy and
Resources](http://www.industry.gov.au "Department of Industry, Science, Energy and Resources"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
