+----------------------------------------------+-----------------------+-----------------------+
| [![coat of                                   |                       | [](index.htm)         |
| arms](imgs/DISER-inline_Mono.png){border="0" |                       |                       |
| width="320"}](http://www.industry.gov.au)    |                       | # FullCAM Help        |
+----------------------------------------------+-----------------------+-----------------------+
|                                              |                       |                       |
+----------------------------------------------+-----------------------+-----------------------+

**Herbicide**

\[[Event Window](137_Event%20Window.htm) : *Herbicide* panel\]

Enter the inputs specific to a herbicide event.

**Details**

A herbicide event moves all crop material into the debris.

A herbicide event set at 100% coverage is classified as a clearing
event.

The only input specific to this event is the percentage of the area
being modelled that is affected.

------------------------------------------------------------------------

© 2025 [Department of Industry, Science, Energy and
Resources](http://www.industry.gov.au "Department of Industry, Science, Energy and Resources"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
