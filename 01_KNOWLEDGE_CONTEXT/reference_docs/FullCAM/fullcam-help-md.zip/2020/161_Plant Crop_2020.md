+----------------------------------------------+-----------------------+-----------------------+
| [![coat of                                   |                       | [](index.htm)         |
| arms](imgs/DISER-inline_Mono.png){border="0" |                       |                       |
| width="320"}](http://www.industry.gov.au)    |                       | # FullCAM Help        |
+----------------------------------------------+-----------------------+-----------------------+
|                                              |                       |                       |
+----------------------------------------------+-----------------------+-----------------------+

**Plant Crop**

\[[Event Window](137_Event%20Window.htm) : *Plant Crop* panel\]

Enter the inputs specific to a crop-planting event.

**Age**

The age of the crop plants when planted, in years. For example, if
planting seedlings at six months, enter "0.5" years. For example, if
planting seeds enter "0.0" years.

**Masses**

The mass of the crop components when planted, in tonnes per hectare.

------------------------------------------------------------------------

© 2025 [Department of Industry, Science, Energy and
Resources](http://www.industry.gov.au "Department of Industry, Science, Energy and Resources"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
