+----------------------------------------------+-----------------------+-----------------------+
| [![coat of                                   |                       | [](index.htm)         |
| arms](imgs/DISER-inline_Mono.png){border="0" |                       |                       |
| width="320"}](http://www.industry.gov.au)    |                       | # FullCAM Help        |
+----------------------------------------------+-----------------------+-----------------------+
|                                              |                       |                       |
+----------------------------------------------+-----------------------+-----------------------+

**Regime Update**

\[*Events* page : *Clone Regimes* Panel\]

\[*Events* page : *Regime Edit* Dialogue\]

**Use**

Regime Timing can be updated for multiple regimes at once. This can be
either a positive or negative offset from the current timing, and is
irrespective of the type (Calendar date or Days since start of
simulation).

Regime Timing may be updated for multiple regimes by multi-selecting the
regimes on the Regime List, and then selecting Clone from the right
mouse options.

**Clone Regime**

Clones the selected regimes and applies an offset to the original events
of the years and days specified. This can be particularly useful if you
wish to clone [Regimes](235_Regimes.htm).

------------------------------------------------------------------------

© 2025 [Department of Industry, Science, Energy and
Resources](http://www.industry.gov.au "Department of Industry, Science, Energy and Resources"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
