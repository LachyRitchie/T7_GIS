+----------------------------------------------+-----------------------+-----------------------+
| [![coat of                                   |                       | [](index.htm)         |
| arms](imgs/DISER-inline_Mono.png){border="0" |                       |                       |
| width="320"}](http://www.industry.gov.au)    |                       | # FullCAM Help        |
+----------------------------------------------+-----------------------+-----------------------+
|                                              |                       |                       |
+----------------------------------------------+-----------------------+-----------------------+

**Soil Water Modifier**

\[[Site : Water](12_Site_Water.htm) window : *Soil Water Modifier*
button\]

**Details**

The soil water modifier is dimensionless, greater than 0, and usually
less than 1. Higher values result in more NPP being produced by the
trees.

The soil water modifier is restricted to values between 0 and 1.

------------------------------------------------------------------------

© 2025 [Department of Industry, Science, Energy and
Resources](http://www.industry.gov.au "Department of Industry, Science, Energy and Resources"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
