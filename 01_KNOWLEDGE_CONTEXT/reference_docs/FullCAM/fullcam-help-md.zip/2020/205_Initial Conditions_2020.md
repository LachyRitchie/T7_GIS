+----------------------------------------------+-----------------------+-----------------------+
| [![coat of                                   |                       | [](index.htm)         |
| arms](imgs/DISER-inline_Mono.png){border="0" |                       |                       |
| width="320"}](http://www.industry.gov.au)    |                       | # FullCAM Help        |
+----------------------------------------------+-----------------------+-----------------------+
|                                              |                       |                       |
+----------------------------------------------+-----------------------+-----------------------+

**Initial Conditions**

\[*Initial Conditions* page of the input window of a plot or spatial
document\]

Enter inputs that describe the situation on the plot at the beginning of
the simulation. It is partitioned into several windows and a panel:

- [Initial Trees](185_Initial%20Trees.htm)
- [Initial Crops](184_Initial%20Crops.htm)
- [Initial Debris](31_Initial%20Debris.htm)
- [Initial Standing Dead](284_Initial%20StandingDead.htm)
- [Initial Soil](32_Initial%20Soil.htm)
- [Initial Products](33_Initial%20Products.htm)
- [Initial Conditions For the Whole
  Plot](197_Initial%20Conditions%20For%20the%20Whole%20Plot.htm)

------------------------------------------------------------------------

© 2025 [Department of Industry, Science, Energy and
Resources](http://www.industry.gov.au "Department of Industry, Science, Energy and Resources"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
