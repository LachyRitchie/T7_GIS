+----------------------------------------------+-----------------------+-----------------------+
| [![coat of                                   |                       | [](index.htm)         |
| arms](imgs/DISER-inline_Mono.png){border="0" |                       |                       |
| width="320"}](http://www.industry.gov.au)    |                       | # FullCAM Help        |
+----------------------------------------------+-----------------------+-----------------------+
|                                              |                       |                       |
+----------------------------------------------+-----------------------+-----------------------+

**Graph Lines**

\[[Output Window](168_Output%20Window.htm) : Double-click on graph to
open the *Graph Settings* window : *Lines* page\]

Choose the properties of an output line in the graph of an *Output
Window*.

**Details**

The line width is in points, for precise control over printed output.
For a given number of points the number of pixels depends on whether or
not you are using small fonts.

If the line width on the screen is not equal to one pixel, then the dash
and dotted styles are drawn on the screen as solid.

Note the buttons for automatically assigning colours and for making all
line widths the same as the first (in the legend) on the output window
toolbar.

------------------------------------------------------------------------

© 2025 [Department of Industry, Science, Energy and
Resources](http://www.industry.gov.au "Department of Industry, Science, Energy and Resources"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
