+---------------------------------------------------------------------+-----------------------+-----------------------+
| [![coat of                                                          |                       | [](index.htm)         |
| arms](imgs/coa_env.png){border="0"}](http://www.environment.gov.au) |                       |                       |
|                                                                     |                       | # FullCAM Help        |
+---------------------------------------------------------------------+-----------------------+-----------------------+
|                                                                     |                       |                       |
+---------------------------------------------------------------------+-----------------------+-----------------------+

**Main Window**

This window is the thin window across the top of your screen with a menu
and toolbar, entitled "FullCAM X.X", where X.X is the version number of
the FullCAM program.

The main window is open whenever FullCAM is open. It is the window
called "FullCAM" in the Windows Taskbar down at the bottom of the
screen. Individual FullCAM documents or windows do not get their own
buttons on the Windows Taskbar.

If you close the main window (by clicking its close box) then you exit
FullCAM.

The main window contains the only fixed menus.

You cannot resize the main window. Although you can move it, we
recommend you always leave it in its original position.

------------------------------------------------------------------------

© 2025 [Department of
Environment](http://www.environment.gov.au "Department of Environment"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
