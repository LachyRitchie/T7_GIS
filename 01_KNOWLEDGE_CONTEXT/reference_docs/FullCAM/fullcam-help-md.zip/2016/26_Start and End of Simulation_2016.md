+---------------------------------------------------------------------+-----------------------+-----------------------+
| [![coat of                                                          |                       | [](index.htm)         |
| arms](imgs/coa_env.png){border="0"}](http://www.environment.gov.au) |                       |                       |
|                                                                     |                       | # FullCAM Help        |
+---------------------------------------------------------------------+-----------------------+-----------------------+
|                                                                     |                       |                       |
+---------------------------------------------------------------------+-----------------------+-----------------------+

**Start and End of Simulation**

\[[Timing](199_Timing.htm) page : *Start and End of Simulation* panel\]

Set the time period over which the simulation runs.

The simulation runs from the beginning of the start date to the end of
the end date.

A number with a red background is not ready. A date is not ready if the
start and end dates are the same or the start date is later than the end
date.

------------------------------------------------------------------------

© 2025 [Department of
Environment](http://www.environment.gov.au "Department of Environment"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
