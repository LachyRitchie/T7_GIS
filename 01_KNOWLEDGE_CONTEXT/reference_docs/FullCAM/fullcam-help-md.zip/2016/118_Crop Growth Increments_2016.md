+---------------------------------------------------------------------+-----------------------+-----------------------+
| [![coat of                                                          |                       | [](index.htm)         |
| arms](imgs/coa_env.png){border="0"}](http://www.environment.gov.au) |                       |                       |
|                                                                     |                       | # FullCAM Help        |
+---------------------------------------------------------------------+-----------------------+-----------------------+
|                                                                     |                       |                       |
+---------------------------------------------------------------------+-----------------------+-----------------------+

**Crop Growth Increments**

\[[Growth Properties](42_Growth%20Properties.htm) window (for crops) :
Any of the *Increments* buttons\]

This [time-series Window](135_time-series%20window.htm) is one of the
crop increment time-series windows, where you specify the growth of the
crop as either:

- Mass increments of various crop components \[tdm/ha\]
- NPP flows to various crop components \[tdm/ha\].

------------------------------------------------------------------------

© 2025 [Department of
Environment](http://www.environment.gov.au "Department of Environment"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
