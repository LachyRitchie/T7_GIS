+---------------------------------------------------------------------+-----------------------+-----------------------+
| [![coat of                                                          |                       | [](index.htm)         |
| arms](imgs/coa_env.png){border="0"}](http://www.environment.gov.au) |                       |                       |
|                                                                     |                       | # FullCAM Help        |
+---------------------------------------------------------------------+-----------------------+-----------------------+
|                                                                     |                       |                       |
+---------------------------------------------------------------------+-----------------------+-----------------------+

**Species or Regime Selection**

\[[Data Builder](132_Data%20Builder.htm) page : *Trees and Events*
panel\]

This window is displayed when the tree or crop species search, or the
forest or agricultural regime search buttons are pressed.

**Details**

Species and regimes are selected by the Species or Regime selection
windows.

Filters may be used to restrict the number of entries in the list
displayed. Filters that may be used are:

[Species or Regime Selection : Text Match
Filter](223_Species%20or%20Regime%20Selection_Text%20Match%20Filter.htm)\
[Species or Regime Selection : Tree or Crop Species
Filter](224_Species%20or%20Regime%20Selection_Tree%20or%20Crop%20Species%20Filter.htm)\
[Species or Regime Selection : Forest or Agricultural Regime
Filter](226_Species%20or%20Regime%20Selection_Forest%20or%20Agricultural%20Regime%20Filter.htm)

------------------------------------------------------------------------

© 2025 [Department of
Environment](http://www.environment.gov.au "Department of Environment"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
