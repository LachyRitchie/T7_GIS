+---------------------------------------------------------------------+-----------------------+-----------------------+
| [![coat of                                                          |                       | [](index.htm)         |
| arms](imgs/coa_env.png){border="0"}](http://www.environment.gov.au) |                       |                       |
|                                                                     |                       | # FullCAM Help        |
+---------------------------------------------------------------------+-----------------------+-----------------------+
|                                                                     |                       |                       |
+---------------------------------------------------------------------+-----------------------+-----------------------+

**Plant Crop**

\[[Event Window](137_Event%20Window.htm) : *Plant Crop* panel\]

Enter the inputs specific to a crop-planting event.

**Age**

The age of the crop plants when planted, in years. For example, if
planting seedlings at six months, enter "0.5" years. For example, if
planting seeds enter "0.0" years.

**Masses**

The mass of the crop components when planted, in tonnes per hectare.

------------------------------------------------------------------------

© 2025 [Department of
Environment](http://www.environment.gov.au "Department of Environment"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
