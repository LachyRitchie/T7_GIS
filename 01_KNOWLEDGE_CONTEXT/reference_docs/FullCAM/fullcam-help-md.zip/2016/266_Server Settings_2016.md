+---------------------------------------------------------------------+-----------------------+-----------------------+
| [![coat of                                                          |                       | [](index.htm)         |
| arms](imgs/coa_env.png){border="0"}](http://www.environment.gov.au) |                       |                       |
|                                                                     |                       | # FullCAM Help        |
+---------------------------------------------------------------------+-----------------------+-----------------------+
|                                                                     |                       |                       |
+---------------------------------------------------------------------+-----------------------+-----------------------+

**Server Settings**

\[*Internet* menu : Server *Settings*\]

This window is for maintaining your FullCAM server settings.

**Use Alternate Server**

This option allows you to specify the address of an alternate server
that FullCAM uses for data. Otherwise the [Department of
Environment](http://www.environment.gov.au) server will be used.

------------------------------------------------------------------------

© 2025 [Department of
Environment](http://www.environment.gov.au "Department of Environment"),
All Rights Reserved. Do not copy without permission.
[Home](index.htm "help index")
